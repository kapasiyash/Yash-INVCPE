#!/bin/sh

JAR_HOME=../lib
#export LD_LIBRARY_PATH=../lib

unset LICENSEJARS
for i in ${JAR_HOME}/*.jar ; do
  if [ "$LICENSEJARS" != "" ]; then
    LICENSEJARS=${LICENSEJARS}:$i
  else
    LICENSEJARS=$i
  fi
done
LICENSEJARS=${LICENSEJARS}:../jar/publickeygenerator.jar

$JAVA_HOME/jre/bin/java -classpath .:"$LICENSEJARS" com.elitecore.licensing.publickeygen.client.GeneratePublicKey $* 
















