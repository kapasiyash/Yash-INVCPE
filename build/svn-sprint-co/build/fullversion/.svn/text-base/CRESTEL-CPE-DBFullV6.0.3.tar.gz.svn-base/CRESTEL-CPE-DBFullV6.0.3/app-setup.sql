set define off

@ setup.sql	
@ default.sql	
@ action.sql
@ template.sql
@ MR.sql
@ Sprint-3.sql

COMMIT;
