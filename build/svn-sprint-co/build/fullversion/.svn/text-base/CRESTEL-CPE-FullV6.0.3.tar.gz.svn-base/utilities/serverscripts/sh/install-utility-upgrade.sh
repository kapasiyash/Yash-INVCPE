#!/bin/sh
#echo "Post Installation Started"

#echo "Installing Reporttool upgrade"
#mkdir -p $BILLING_HOME/wars/corereports/reportstool
#cd $BILLING_HOME/wars/corereports/reportstool
#gunzip $BILLING_HOME/modules/reportstool/reportstool.tar.gz
#tar xvf $BILLING_HOME/modules/reportstool/reportstool.tar
#rm -rf $BILLING_HOME/modules/reportstool/reportstool.tar
#echo "reporttool installation completed"

#ant -f $BILLING_HOME/modules/provisioning/clients/ws/war/build.xml