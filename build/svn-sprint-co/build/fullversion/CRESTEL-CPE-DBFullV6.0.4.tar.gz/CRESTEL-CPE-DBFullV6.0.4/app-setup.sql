set define off

@ setup.sql	
@ default.sql	
@ action.sql
@ template.sql
@ MR.sql
@ Sprint-3.sql
@ Crestel-CPE-DB-6.0.3-MR01.sql
@ Sprint-4.sql

COMMIT;
